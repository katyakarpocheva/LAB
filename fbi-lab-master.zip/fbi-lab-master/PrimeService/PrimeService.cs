﻿using System;

namespace Prime.Services
{
    public class PrimeService
    {
        public string PrimeName(string name)
	    {
                return name.ToUpper();
        }
    }
}